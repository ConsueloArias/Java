package mayorxnumeros;

import java.util.Scanner;

public class MayorXNumeros {

    public static void main(String[] args) {
        Scanner intro = new Scanner(System.in);
        int cantNum;
        int mayor = 0;
        int num;

        System.out.println("Ingrese la cantidad de numeros");
        cantNum = intro.nextInt();
        
        for (int i = 0; i < cantNum; i++){
            System.out.println("Ingrese un numero");
            num = intro.nextInt();
            if (num>mayor){
                mayor = num;
            }
        }
        System.out.println("El numero mayor es: " + mayor);

    }

}
