package mayorcuatronumeros;
import java.util.Scanner;

public class MayorCuatroNumeros {

    public static void main(String[] args) {
        
        Scanner intro = new Scanner(System.in);
        int x = 0;
        int num = 0;
        int mayor = 0;
        int cantNum;
        System.out.println("Ingrese la cantidad de numeros");
        cantNum = intro.nextInt();
        
        
        while(x<cantNum){
            System.out.println("Ingrese un numero");
            num = intro.nextInt();
            x++;
            if (num>mayor){
                
                
                mayor = num;
            }
        }
        System.out.println("El mayor de los numeros es: " + mayor);
 
    }
    
}
